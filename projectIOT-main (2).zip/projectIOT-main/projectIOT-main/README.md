# projectIOT
Project semester 222 HCMUT